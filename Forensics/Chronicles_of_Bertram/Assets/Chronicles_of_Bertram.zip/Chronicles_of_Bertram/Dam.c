#include <stdlib.h>
#include <stdio.h>

#include "Peasants.h"

int main(){
    printBeginning();

    printf("\n");
    
    void* dam = makeDam();
    DamStory();
    return 0;
}